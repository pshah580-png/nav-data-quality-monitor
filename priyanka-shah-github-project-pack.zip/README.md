# GitHub Project Pack — Priyanka Shah

**What this is:** Two complete, self-contained portfolio projects, ready to upload to GitHub as two separate repositories. They were built to give you credible proof of work that matches your resume — fund-administration BI, data quality, and reporting automation — without ever using employer data.

> **Data honesty:** All data in both projects is **synthetic demo data — created for portfolio demonstration; not employer data.** Every result quoted is a demo-scenario result from running the code on that synthetic data. Nothing here claims to be a real employer project.

## First, an honest assessment of what you already had

- **GitHub — `NYC-Taxi-Dashboard`:** the repository exists but is **empty** (no files, no README, no code). On its own it would hurt more than help — a recruiter who clicks it finds nothing. Two options: upload Project 1 or 2's contents into it (steps below), or delete/rename it once the two new repos are live. A second repo, `Kaggle-datasource`, holds a single retail-sales dataset file with no analysis — also not yet portfolio-grade.
- **Tableau Public:** your profile is live with a strong bio, but a profile link alone doesn't show *how* you work. These two projects cover the SQL + Python side that Tableau can't; link all three together (each project README already links back to your Tableau profile).

**Verdict:** your existing projects weren't complex enough to carry the portfolio on their own, so this pack creates the two below — each one mirrors a real theme from your fund-administration BI experience (NAV data quality; recurring reporting automation) rebuilt entirely on fictional data.

## The two projects

### 1. `nav-data-quality-monitor/`
Checks daily NAV completeness for 30 fictional funds: finds missing fund/dates, duplicates and weekend date-mapping errors, then reconciles the report feed against a source of record and restores it — completeness goes from **74.9% → 100%** across the demo months (synthetic data; see its README and `output/completeness_trend.png`).
**Shows:** SQL validation & reconciliation, Python + SQLite pipelines, data-quality controls, matplotlib.

### 2. `financial-reporting-automation/`
Automates recurring trade/positions reporting: generates the daily trade summary, account activity and positions snapshot from a report schedule, verifies a control total, and writes a timestamped audit log for every run.
**Shows:** Python automation, SQL aggregation, reporting controls & audit trails, scheduling concepts.

## How to upload each folder as its own GitHub repository

Do this once per project (about 5 minutes each). No command line needed for the first upload — the web flow below is fine for projects this size, except the larger CSVs noted in step 4.

1. **Unzip** this pack on your computer. You'll see two folders: `nav-data-quality-monitor` and `financial-reporting-automation`.
2. On [github.com](https://github.com) (signed in as **pshah580-png**), click **+ → New repository**. Name it exactly `nav-data-quality-monitor`, add the description *"NAV completeness & data-quality monitor — SQL validation + Python reconciliation pipeline (synthetic demo data)"*, choose **Public**, and click **Create repository** (don't tick "Add a README" — the folder already has one).
3. On the empty-repo page, click **uploading an existing file**. Drag in **everything inside** the `nav-data-quality-monitor` folder (the README, `data/`, `sql/`, `python/`, `output/`, `requirements.txt` — including the folder structure; GitHub keeps the subfolders when you drag the folders themselves). Write a commit message like `Initial commit: NAV data quality monitor` and click **Commit changes**.
4. **File-size note:** all files here are small (largest CSV ≈ 150 KB), well under GitHub's web-upload limits, so the drag-and-drop flow works for everything in this pack.
5. **Repeat** steps 2–4 for `financial-reporting-automation` (description: *"Automated recurring financial reporting with control totals & audit log — Python + SQL (synthetic demo data)"*).
6. **Pin both repos:** on your profile, click **Customize your pins** and pin the two new repositories so they're the first thing a recruiter sees.
7. **Then handle `NYC-Taxi-Dashboard`:** either delete it (repo → Settings → Danger Zone → Delete) or, if you'd rather keep the name, upload one project's contents into it instead and create only one new repo. Don't leave it empty and pinned.

### Optional: uploading with Git instead

```bash
cd nav-data-quality-monitor
git init && git add . && git commit -m "Initial commit: NAV data quality monitor"
git branch -M main
git remote add origin https://github.com/pshah580-png/nav-data-quality-monitor.git
git push -u origin main
```

## Before you share the links

- Run each project once on your own machine (`python python/nav_quality_pipeline.py` / `python python/generate_reports.py`) so you can talk through exactly what it does in an interview — both run in under a minute.
- Add the two repo links next to your Tableau Public link on your resume and LinkedIn.
- In interviews, describe them accurately: *"portfolio projects I built on synthetic data, modelled on the kind of NAV data-quality and reporting work I did in fund administration."* That framing is both honest and strong.

— Prepared for Priyanka Shah · Tableau: https://public.tableau.com/app/profile/priyanka.shah1267/vizzes · GitHub: https://github.com/pshah580-png
